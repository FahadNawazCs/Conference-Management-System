import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import './PaperSubmission.css';

function PaperSubmission() {
    const [conferenceName, setConferenceName] = useState('');
    const [profile, setProfile] = useState(null);
    const [title, setTitle] = useState('');
    const [abstract, setAbstract] = useState('');
    const [file, setFile] = useState(null);
    const [keywords, setKeywords] = useState('');
    useEffect(() => {
        const storedConferenceName = localStorage.getItem('currentConferenceName');
        if (storedConferenceName) {
            setConferenceName(storedConferenceName);
        }
        axios.get('/api/profile/', {
            headers: {
                Authorization: `Token ${localStorage.getItem('token')}`
            }
        })
            .then(response => {
                setProfile(response.data);
            })
            .catch(error => {
                console.error('Error fetching profile:', error);
            });
    }, []);

    const handleTitleChange = (e) => {
        setTitle(e.target.value);
    };

    const handleAbstractChange = (e) => {
        setAbstract(e.target.value);
    };

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleKeywordsChange = (e) => {
        setKeywords(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('title', title);
        formData.append('abstract', abstract);
        formData.append('keywords', keywords); // Add keywords to the form data
        formData.append('uploaded_file', file);
        formData.append('conference', conferenceName);
        formData.append('user', profile.email);

        try {
            const response = await axios.post('/api/papers/', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Token ${localStorage.getItem('token')}`,
                },
            });
            console.log('Success:', response.data);
            alert('Paper submitted successfully!');
        } catch (error) {
            console.error('Error submitting paper:', error.response.data);
            alert(`Failed to submit paper: ${JSON.stringify(error.response.data)}`);
        }
    };

    return (
        <div className="submission-form">
            <Navbar />
            <h1>Create New Submission</h1>
            <h2>Conference: {conferenceName}</h2>
            {/* Display conference name */}
            <form onSubmit={handleSubmit}>
                <div className="input-group">
                    <label>Title</label>
                    <input type="text" value={title} onChange={handleTitleChange} required />
                </div>
                <div className="input-group">
                    <label>Abstract</label>
                    <textarea value={abstract} onChange={handleAbstractChange} required />
                </div>
                <div className="input-group">
                    <label>Keywords</label>
                    <input type="text" value={keywords} onChange={handleKeywordsChange} required />
                </div>
                <div className="file-upload">
                    <input type="file" onChange={handleFileChange} accept="application/pdf" required />
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
    );
}

export default PaperSubmission;


