import React from "react";
import "./Navbar.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import DropDown from "./DropDown";
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="navbar">
      <ul>
        <li>
          <h3><Link to="/home">FAST CMS</Link></h3>
        </li>
        <li className="right-side">
          <div className="search-dropdown-wrapper">
            <div className="search-box">
              <input type="text" placeholder="search conference" />
              <button className="searchButton">
                <FontAwesomeIcon icon={faSearch} />{" "}
              </button>
            </div>
            <Link to="/extract-keywords" className="extract-link">Extract Keywords</Link>
            <div className="dropdown-body">
              <DropDown />
            </div>
          </div>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
