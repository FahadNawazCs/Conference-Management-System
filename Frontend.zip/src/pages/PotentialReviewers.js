import React, { useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
//import './PotentialReviewers.css';

const PotentialReviewers = () => {
    const [file, setFile] = useState(null);
    const [result, setResult] = useState(null);
    const [error, setError] = useState(null);

    const handleFileChange = (event) => {
        setFile(event.target.files[0]);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        if (!file) {
            setError('Please select a file to upload.');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await axios.post('/api/potential_reviewers/', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            setResult(response.data);
            setError(null);
        } catch (error) {
            setError('Failed to fetch potential reviewers.');
            console.error('Error:', error);
        }
    };

    return (
        <div>
            <Navbar />
            <div className="potential-reviewers-container">
                <h1 className="potential-reviewers-header">Potential Reviewers</h1>
                <form onSubmit={handleSubmit} className="form-container">
                    <label>
                        Upload JSON File:
                        <input type="file" onChange={handleFileChange} accept=".json" className="input-field" required />
                    </label>
                    <button type="submit" className="button-extract">Submit</button>
                </form>
                {error && <div style={{ color: 'red' }}>{error}</div>}
                {result && (
                    <div className="result">
                        <h2>Results:</h2>
                        <ul className='potential-reviewers-results'>
                            {result.results && Object.entries(result.results).map(([link, texts]) => (
                                <li key={link}>
                                    <strong>{link}</strong>
                                    <ul className='potential-reviewers-results'>
                                        {Array.isArray(texts) ? texts.map((text, index) => (
                                            <li key={index}>
                                                {typeof text === 'string' ? text : (
                                                    <>
                                                        {Object.entries(text).map(([key, value]) => (
                                                            <div key={key}>
                                                                <strong>{key}:</strong> {value}
                                                            </div>
                                                        ))}
                                                    </>
                                                )}
                                            </li>
                                        )) : <li>{texts}</li>}
                                    </ul>
                                </li>
                            ))}
                        </ul>


                    </div>
                )}
            </div>
        </div>
    );
};

export default PotentialReviewers;
