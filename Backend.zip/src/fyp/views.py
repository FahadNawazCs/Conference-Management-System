from rest_framework import viewsets
import datetime
from datetime import datetime
from .models import Users, Conferences, Form, Papers, Settings
from .serializers import (UserSerializer, ConferencesSerializer, FormSerializer, 
                            PapersSerializer, SettingsSerializer)

from django.contrib.auth import authenticate
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.authtoken.models import Token
from rest_framework import status, generics

import fitz  # PyMuPDF
import re
import os
from django.http import JsonResponse
import time
import requests
from django.conf import settings
from bs4 import BeautifulSoup
import json
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import default_storage
import logging


@api_view(['POST'])
def signup_view(request):
    username = request.data.get('username')
    password = request.data.get('password')
    email = request.data.get('email')
    phone = request.data.get('phone')
    real_name = request.data.get('realName')
    institution = request.data.get('institution')
    googleScholarId = request.data.get('googleScholarId')
    role = request.data.get('role')

    if not (username and password and email):
        return JsonResponse({'error': 'Missing required fields'}, status=status.HTTP_400_BAD_REQUEST)

    if Users.objects.filter(username=username).exists():
        return JsonResponse({'error': 'Username already taken'}, status=status.HTTP_400_BAD_REQUEST)

    user = Users.objects.create_user(
        username=username,
        email=email,
        password=password,
        phone=phone,
        real_name=real_name,
        institution=institution,
        googleScholarId=googleScholarId,
        role=role
    )
    user.save()

    return JsonResponse({'success': 'Users created successfully'}, status=status.HTTP_201_CREATED)

@api_view(['POST'])
def login_view(request):
    username = request.data.get('username')
    password = request.data.get('password')
    user = authenticate(username=username, password=password)

    if user is not None:
        token, _ = Token.objects.get_or_create(user=user)
        return Response({'token': token.key,'role':user.role}, status=status.HTTP_200_OK)
    else:
        return Response({'error': 'Invalid Credentials'}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def profile_view(request):
    user = request.user
    if not user.is_anonymous:
        return Response({
            'username': user.username,
            'email': user.email,
            'phone': user.phone,
            'real_name': user.real_name,
            'institution': user.institution,
            'googleScholarId': user.googleScholarId,
            'role':user.role,
        })
    else:
        return Response({'error': 'Not authenticated'}, status=401)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def update_email(request):
    user = request.user
    current_email = request.data.get('currentEmail')
    new_email = request.data.get('newEmail')

    if user.email != current_email:
        return Response({'error': 'Current email does not match.'}, status=status.HTTP_400_BAD_REQUEST)

    if user.email == new_email:
        return Response({'error': 'The new email is the same as the current email.'}, status=status.HTTP_400_BAD_REQUEST)

    user.email = new_email
    user.save()

    return Response({'success': 'Email updated successfully.'})

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_conference(request):
    serializer = ConferencesSerializer(data=request.data)
    if serializer.is_valid():
        conference = serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

###################



def read_json_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        data = json.load(file)
    return data

def extract_author_links(data):
    author_links = []
    for result in data:
        publication_info = result.get('publication_info', {})
        authors = publication_info.get('authors', [])
        for author in authors:
            author_link = author.get('link')
            if author_link:
                author_links.append(author_link)
    return author_links

def get_coauthor_links(soup, limit=3):
    coauthors_div = soup.find('div', id='gsc_rsb_co')
    if coauthors_div:
        coauthor_links = []
        for link in coauthors_div.find_all('a'):
            if link.get('href') and 'citations?user' in link['href'] and len(coauthor_links) < limit:
                coauthor_links.append(link['href'])
        return coauthor_links
    return []

def fetch_text_associated_with_links(url, original_data):
    response = requests.get(url, headers={"User-agent": "CMS-Test"})

    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")

        target_div = soup.find("div", {"class": "gsc_prf_il", "id": "gsc_prf_int"})

        if target_div:
            links_with_text = []
            for link in target_div.find_all("a", href=True):
                text = link.text.strip()
                href = link["href"]
                if text and href:
                    links_with_text.append((text, href))
            
            if links_with_text: 
                return links_with_text
            else:
                for item in original_data:
                    if item.get("publication_info", {}).get("authors", []):  
                        for author in item["publication_info"]["authors"]:
                            if author["link"] == url:
                                if item.get("resources"):
                                    for resource in item["resources"]:
                                        if resource.get("file_format") == "PDF":
                                            pdf_link = resource.get("link")
                                            if pdf_link:
                                                pdf_response = requests.get(pdf_link)
                                                if pdf_response.status_code == 200:
                                                    files = {'file': ('document.pdf', pdf_response.content, 'application/pdf')}
                                                    keyword_response = requests.post(
                                                        f"{settings.BASE_URL}/api/extract_keywords/",
                                                        files=files,
                                                    )
                                                    if keyword_response.status_code == 200:
                                                        return keyword_response.json().get('extracted_keywords', [])
                                                    else:
                                                        logger.error(f"Keyword extraction failed: {keyword_response.status_code}")
                                                else:
                                                    logger.error(f"Failed to download PDF: {pdf_response.status_code}")

                coauthor_links = get_coauthor_links(soup)
                for coauthor_link in coauthor_links:
                    coauthor_keywords = fetch_text_associated_with_links(
                        coauthor_link, original_data
                    )
                    if coauthor_keywords:
                        return coauthor_keywords
        else:
            logger.error(f"Target div not found for {url}")  
    elif response.status_code == 429:
        logger.warning(f"Rate limited. Status code: {response.status_code}")
        if 'Retry-After' in response.headers:
            retry_after = int(response.headers['Retry-After'])
            logger.info(f"Rate limited. Waiting {retry_after} seconds and retrying...")
            time.sleep(retry_after)
            return fetch_text_associated_with_links(url, original_data)
        else:
            logger.info("Rate limited. Waiting and retrying...")
            time.sleep(60)  # Default wait time
            return fetch_text_associated_with_links(url, original_data)
    else:
        logger.error(f"Failed to fetch data from {url}. Status code: {response.status_code}")
    return []  # Return empty list if no links found or error occurs


@csrf_exempt
def potential_reviewers(request):
    if request.method == 'POST':
        logger.debug('POST request received')
        if 'file' not in request.FILES:
            logger.error('No file part in the request')
            return JsonResponse({'error': 'No file part in the request'}, status=400)

        file = request.FILES['file']
        if file.name == '':
            logger.error('No selected file')
            return JsonResponse({'error': 'No selected file'}, status=400)

        if file and file.name.lower().endswith('.json'):
            file_path = default_storage.save(file.name, file)
            full_file_path = default_storage.path(file_path)
            logger.debug(f'File saved to {full_file_path}')

            try:
                data = read_json_file(full_file_path)
                author_links = extract_author_links(data)
                result = {}

                for link in author_links:
                    associated_texts = fetch_text_associated_with_links(link, data)
                    result[link] = associated_texts if associated_texts else "No associated texts found"

                output_file_path = os.path.join(settings.MEDIA_ROOT, 'potential_reviewers_results.json')
                with open(output_file_path, 'w', encoding='utf-8') as output_file:
                    json.dump(result, output_file, ensure_ascii=False, indent=4)

                return JsonResponse({'results': result, 'output_file': output_file_path})
            except Exception as e:
                logger.error(f'Error processing file: {str(e)}')
                return JsonResponse({'error': str(e)}, status=500)
            finally:
                if default_storage.exists(file_path):
                    default_storage.delete(file_path)
                    logger.debug(f'File {file_path} deleted after processing')
        else:
            logger.error('Invalid file format. Please upload a JSON file.')
            return JsonResponse({'error': 'Invalid file format. Please upload a JSON file.'}, status=400)

    logger.error('Invalid request method')
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@csrf_exempt
def extract_keywords(request):
    if request.method == 'POST':
        logger.debug("POST request received")
        if 'file' not in request.FILES:
            logger.error("No file part in the request")
            return JsonResponse({'error': 'No file part in the request'}, status=400)

        file = request.FILES['file']
        if file.name == '':
            logger.error("No selected file")
            return JsonResponse({'error': 'No selected file'}, status=400)

        if file and file.name.lower().endswith('.pdf'):
            file_path = default_storage.save(file.name, file)
            full_file_path = default_storage.path(file_path)
            logger.debug(f"File saved to {full_file_path}")

            try:
                text = extract_text_from_pdf(full_file_path)
                found_keywords = extract_keywords_from_text(text)
                os.remove(full_file_path)
                logger.debug(f"Keywords extracted: {found_keywords}")
                return JsonResponse({'extracted_keywords': found_keywords})
            except Exception as e:
                logger.error(f"Error processing file: {e}")
                return JsonResponse({'error': str(e)}, status=500)
        else:
            logger.error("Invalid file format. Please upload a PDF file.")
            return JsonResponse({'error': 'Invalid file format. Please upload a PDF file.'}, status=400)

    logger.error("Invalid request method")
    return JsonResponse({'error': 'Invalid request method'}, status=405)

def extract_text_from_pdf(pdf_path):
    pdf_document = fitz.open(pdf_path)
    all_text = ""

    for page_num in range(len(pdf_document)):
        page = pdf_document.load_page(page_num)
        all_text += page.get_text()

    return all_text

def extract_keywords_from_text(text):
    import re
    match = re.search(r'Keywords\s*:\s*([\s\S]*?)(?=\n{2,}|\.\s|\.$|$)', text, re.IGNORECASE)
    if match:
        keywords = match.group(1).split(',')
        return [keyword.strip() for keyword in keywords]
    return []


CURRENT_YEAR = datetime.now().year
START_YEAR = CURRENT_YEAR - 5

def fetch_citations(url):
    response = requests.get(url, headers={"User-agent": "CMS-Test"})
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        papers = []

        # Find the papers and their publication years and citations
        for paper in soup.select('.gsc_a_tr'):
            title_element = paper.select_one('.gsc_a_at')
            if title_element:
                title = title_element.text.strip()
                year_element = paper.select_one('.gsc_a_h .gsc_a_hc')
                if year_element:
                    year = int(year_element.text.strip())
                    if START_YEAR <= year <= CURRENT_YEAR:
                        citation_element = paper.select_one('.gsc_a_ac')
                        if citation_element:
                            citations = citation_element.text.strip()
                            citations = int(citations) if citations else 0
                            papers.append({
                                'title': title,
                                'year': year,
                                'citations': citations
                            })
        return papers
    else:
        print(f"Failed to fetch data from {url}. Status code: {response.status_code}")
    return []

def assign_scores(papers):
    for paper in papers:
        paper['score'] = paper['citations']  # Simple score formula: score = number of citations
    return papers

def process_reviewers_data(json_file_path):
    data = read_json_file(json_file_path)
    results = {}
    
    for author, links in data.items():
        author_results = []
        for link_text, link_url in links:
            if 'citations?user' in link_url:
                papers = fetch_citations(link_url)
                papers_with_scores = assign_scores(papers)
                author_results.append({
                    'profile_link': link_url,
                    'papers': papers_with_scores
                })
        results[author] = author_results
    
    # Save the results to a new JSON file
    output_file_path = os.path.join(settings.MEDIA_ROOT, 'author_citations_scores.json')
    with open(output_file_path, 'w', encoding='utf-8') as output_file:
        json.dump(results, output_file, ensure_ascii=False, indent=4)
    
    print(f'Results saved to {output_file_path}')
    return results



class UserViewSet(viewsets.ModelViewSet):
    queryset = Users.objects.all()
    serializer_class = UserSerializer


class ConferencesViewSet(viewsets.ModelViewSet):
    queryset = Conferences.objects.all()
    serializer_class = ConferencesSerializer

class FormViewSet(viewsets.ModelViewSet):
    queryset = Form.objects.all()
    serializer_class = FormSerializer

class PapersViewSet(viewsets.ModelViewSet):
    queryset = Papers.objects.all()
    serializer_class = PapersSerializer

    def get_queryset(self):
        queryset = Papers.objects.all()
        conference_name = self.request.query_params.get('conference_name', None)
        if conference_name is not None:
            queryset = queryset.filter(conference__full_name=conference_name)
        return queryset


class SettingsViewSet(viewsets.ModelViewSet):
    queryset = Settings.objects.all()
    serializer_class = SettingsSerializer

