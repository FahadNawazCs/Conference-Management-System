import React, { useEffect, useState } from "react";
import "./Home.css";
import Navbar from "../components/Navbar";
import { Link } from 'react-router-dom';
import Conferences from '../components/Conferences';
import Button from "@mui/material/Button";

const Home = () => {
  const [role, setRole] = useState('');

  useEffect(() => {
    // Retrieve the user role from localStorage
    const userRole = localStorage.getItem('role');
    if (userRole) {
      setRole(userRole);
    }
  }, []);

  return (
    <div>
      <Navbar />
      <h1>Conferences</h1>
      {role === 'chair' && (
        <Button
          variant="contained"
          className="create-conference"
          style={{ width: "18rem", height: "3rem", marginBottom: "20px" }}
        >
          <Link to="/create-conference" style={{ color: "white", textDecoration: "none" }}>
            Create Conference
          </Link>
        </Button>
      )}
      <div className="App">
        <Conferences />
      </div>
    </div>
  );
};

export default Home;
