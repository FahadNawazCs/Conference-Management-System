from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class CustomUserManager(BaseUserManager):
    def create_user(self, username, email, password=None, **extra_fields):
        if not username:
            raise ValueError('The Username must be set')
        if not email:
            raise ValueError('The Email must be set')

        email = self.normalize_email(email)
        user = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

class Users(AbstractBaseUser, models.Model):
    ROLE_CHOICES = [
        ('author', 'Author'),
        ('chair', 'Chair'),
        ('reviewer', 'Reviewer'),
    ]

    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=100)
    email = models.EmailField(max_length=100, unique=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    real_name = models.CharField(max_length=100, blank=True, null=True)
    institution = models.CharField(max_length=100, blank=True, null=True)
    googleScholarId = models.CharField(max_length=100, blank=True, null=True)
    role = models.CharField(max_length=8, choices=ROLE_CHOICES, default='author')

    is_active = models.BooleanField(default=True)
    objects = CustomUserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email', 'password']

    class Meta:
        db_table = 'user'

class Document(models.Model):
    title = models.CharField(max_length=255)
    uploaded_file = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'document'

class Conferences(models.Model):
    user = models.ForeignKey(Users, to_field='email', on_delete=models.SET_NULL, blank=True, null=True)
    full_name = models.CharField(max_length=200, default='New Conference')
    short_name = models.CharField(max_length=100, default='NC')
    topics = models.CharField(max_length=200)
    city = models.CharField(max_length=100, blank=True, null=True)
    country = models.CharField(max_length=100, blank=True, null=True)
    starting_date = models.DateField(default="2024-01-01")
    ending_date = models.DateField(default="2024-01-01")
    submission_due_date = models.DateField(default="2024-01-01")
    external_url = models.URLField(blank=True, null=True)

    class Meta:
        db_table = 'conferences'

class Form(models.Model):
    reviewer_grade = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        db_table = 'form'

class Papers(models.Model):
    ACCEPTANCE_CHOICES = [
        ('Accepted', 'Accepted'),
        ('Rejected', 'Rejected'),
        ('Pending', 'Pending')
    ]
    acceptance = models.CharField(max_length=8, choices=ACCEPTANCE_CHOICES, blank=True, null=True, default='Pending')
    conference = models.ForeignKey(Conferences, on_delete=models.SET_NULL, blank=True, null=True)
    title = models.CharField(max_length=100, blank=True, null=True)
    abstract = models.TextField(max_length=5000, blank=True, null=True)
    keywords = models.CharField(max_length=200, blank=True, null=True)
    uploaded_file = models.FileField(upload_to='documents/', blank=True, null=True)
    user = models.ForeignKey(Users, to_field='email', on_delete=models.SET_NULL, blank=True, null=True)

    class Meta:
        db_table = 'papers'

class Settings(models.Model):
    num_of_reviewers = models.IntegerField(blank=True, null=True)

    class Meta:
        db_table = 'settings'
