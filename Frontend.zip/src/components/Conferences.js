// src/components/Conferences.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import "./Conferences.css";

const Conferences = () => {
    const [conferences, setConferences] = useState([]);

    useEffect(() => {
        const fetchConferences = async () => {
            try {
                const response = await axios.get('/api/conferences/');
                setConferences(response.data);
            } catch (error) {
                console.error('Error fetching data:', error);
                setConferences([]);
            }
        };

        fetchConferences();
    }, []);

    const handleConferenceClick = (conferenceName) => {
        localStorage.setItem('currentConferenceName', conferenceName);
    };

    return (
        <div>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Start Date</th>
                        <th>Submission Due Date</th>
                        <th>External URL</th>
                    </tr>
                </thead>
                <tbody>
                    {conferences.map(conference => (
                        <tr key={conference.id}>
                            <td>
                                <Link to="/conference-page/" onClick={() => handleConferenceClick(conference.full_name)}>
                                    {conference.full_name}
                                </Link>
                            </td>
                            <td>{conference.starting_date}</td>
                            <td>{conference.submission_due_date}</td>
                            <td>
                                <a href={conference.external_url} target="_blank" rel="noopener noreferrer">{conference.external_url}</a>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default Conferences;
