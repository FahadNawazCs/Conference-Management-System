import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "./Profile.css"; // Ensure this path is correct
import Navbar from "../components/Navbar"; // Adjust the path as per your project structure
import { Link } from 'react-router-dom';  // Import useNavigate

const Profile = () => {
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    axios.get('/api/profile/', { headers: { Authorization: `Token ${localStorage.getItem('token')}` } })
      .then(response => {
        setProfile(response.data);
      })
      .catch(error => {
        console.error('Error fetching profile:', error);
      });
  }, []);

  if (!profile) {
    return <div>Loading profile...</div>;
  }

  return (
    <div>
      <Navbar />
      <div className="main-content"> {/* Main content starts here */}
        <div className="user-profile-form"> {/* User profile form */}
          <h1 className="form-header">Profile</h1> {/* Header */}
          <p><span className="label">Username:</span> {profile.username}</p>
          <p><span className="label">Email:</span> {profile.email}</p>
          <button className="change-email-button">
            <Link to="/edit-email" style={{ /*color: "blue",*/ textDecoration: "none" }}>
              Change Email
            </Link>
          </button>
          <p><span className="label">Phone No.:</span> {profile.phone}</p>
          <p><span className="label">Full Name:</span> {profile.real_name}</p>
          <p><span className="label">Institution:</span> {profile.institution}</p>
          <p><span className="label">Google Scholar ID:</span> {profile.googleScholarId}</p>
          <p><span className="label">Role:</span> {profile.role}</p>

        </div>
      </div>
    </div>
  );
};

export default Profile;
