import React, { useState, useEffect } from "react";
import "./CreateConference.css";
import Navbar from "../components/Navbar";
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ConferenceForm = () => {
  const [conferenceData, setConferenceData] = useState({
    user: "",
    full_name: "",
    short_name: "",
    topics: "",
    city: "",
    country: "",
    starting_date: "",
    ending_date: "",
    submission_due_date: "",
    external_url: ""
  });

  const navigate = useNavigate();

  useEffect(() => {
    // Fetch the profile data to get the user's email
    const fetchProfile = async () => {
      try {
        const response = await axios.get('/api/profile/', {
          headers: { Authorization: `Token ${localStorage.getItem('token')}` }
        });
        const profileData = response.data;
        setConferenceData(prevState => ({ ...prevState, user: profileData.email }));
      } catch (error) {
        console.error('Error fetching profile:', error);
      }
    };

    fetchProfile();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setConferenceData(prevState => ({ ...prevState, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('/api/create-conference/', conferenceData, {
        headers: { Authorization: `Token ${localStorage.getItem('token')}` },
      });
      console.log('Conference creation successful', response.data);
      navigate('/home'); // Navigate to home or another page after successful creation
    } catch (error) {
      console.error('Error creating conference:', error);
    }
  };

  return (
    <div className="conference-container">
      <Navbar />
      <form onSubmit={handleSubmit} className="form-container">
        <label>
          Email:
          <input type="email" name="user" value={conferenceData.user} onChange={handleChange} readOnly required />
        </label>
        <label>
          Conference Full Name:
          <input type="text" name="full_name" value={conferenceData.full_name} onChange={handleChange} required />
        </label>
        <label>
          Conference Short Name:
          <input type="text" name="short_name" value={conferenceData.short_name} onChange={handleChange} required />
        </label>
        <label>
          Topics:
          <input type="text" name="topics" value={conferenceData.topics} onChange={handleChange} required />
        </label>
        <label>
          City:
          <input type="text" name="city" value={conferenceData.city} onChange={handleChange} required />
        </label>
        <label>
          Country:
          <input type="text" name="country" value={conferenceData.country} onChange={handleChange} required />
        </label>
        <label>
          Start Date:
          <input type="date" name="starting_date" value={conferenceData.starting_date} onChange={handleChange} required />
        </label>
        <label>
          End Date:
          <input type="date" name="ending_date" value={conferenceData.ending_date} onChange={handleChange} required />
        </label>
        <label>
          Paper Submission Due Date:
          <input type="date" name="submission_due_date" value={conferenceData.submission_due_date} onChange={handleChange} required />
        </label>
        <label>
          External URL:
          <input type="url" name="external_url" value={conferenceData.external_url} onChange={handleChange} required />
        </label>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default ConferenceForm;
