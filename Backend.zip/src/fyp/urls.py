
from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views
from django.conf import settings
from django.conf.urls.static import static

router = DefaultRouter()
router.register(r'users', views.UserViewSet)
router.register(r'conferences', views.ConferencesViewSet)
router.register(r'forms', views.FormViewSet)
router.register(r'papers', views.PapersViewSet)
router.register(r'settings', views.SettingsViewSet)

urlpatterns = [
    path("admin/", admin.site.urls),
    path('api/', include(router.urls)),
    path('api/login/', views.login_view, name='login'),
    path('api/signup/', views.signup_view, name='signup'),
    path('api/profile/', views.profile_view, name='profile'),
    path('api/update-email/', views.update_email, name='update_email'),
    path('api/create-conference/', views.create_conference, name='create-conference'),
    path('api/extract_keywords/', views.extract_keywords, name='extract_keywords'),
    path('api/potential_reviewers/', views.potential_reviewers, name='potential_reviewers'),

    
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)