from rest_framework import serializers
from .models import Users, Conferences, Form, Papers, Settings

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = '__all__'



class ConferencesSerializer(serializers.ModelSerializer):
    user = serializers.SlugRelatedField(slug_field='email', queryset=Users.objects.all(), required=False)

    class Meta:
        model = Conferences
        fields = '__all__'

class FormSerializer(serializers.ModelSerializer):
    class Meta:
        model = Form
        fields = '__all__'

class PapersSerializer(serializers.ModelSerializer):
    conference = serializers.SlugRelatedField(slug_field='full_name', queryset=Conferences.objects.all(), required=False)
    user = serializers.SlugRelatedField(slug_field='email', queryset=Users.objects.all(), required=False)

    class Meta:
        model = Papers
        fields = ['id', 'acceptance', 'conference', 'title', 'abstract', 'keywords', 'uploaded_file', 'user']

    def create(self, validated_data):
        return Papers.objects.create(**validated_data)

class SettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Settings
        fields = '__all__'

# If you have a CameraReadyPaper model, you would also create a serializer for it.
# For example:

# class CameraReadyPaperSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = CameraReadyPaper
#         fields = '__all__'

# Similarly, if you have additional models or many-to-many relationships,
# you would need to create serializers for those as well.
