// src/services/apiService.js

import axios from 'axios';

const API_BASE_URL = '/api'; // The base URL, assuming you have set up a proxy in package.json

const apiService = {
  // User endpoints
  fetchUsers: () => axios.get(`${API_BASE_URL}/users/`),
  createUser: (userData) => axios.post(`${API_BASE_URL}/users/`, userData),

  // Author endpoints
  fetchAuthors: () => axios.get(`${API_BASE_URL}/authors/`),
  createAuthor: (authorData) => axios.post(`${API_BASE_URL}/authors/`, authorData),

  // Chair endpoints
  fetchChairs: () => axios.get(`${API_BASE_URL}/chairs/`),
  createChair: (chairData) => axios.post(`${API_BASE_URL}/chairs/`, chairData),

  // Conferences endpoints
  fetchConferences: () => axios.get(`${API_BASE_URL}/conferences/`),
  createConference: (conferenceData) => axios.post(`${API_BASE_URL}/conferences/`, conferenceData),

  // Form endpoints
  fetchForms: () => axios.get(`${API_BASE_URL}/forms/`),
  createForm: (formData) => axios.post(`${API_BASE_URL}/forms/`, formData),

  // Papers endpoints
  fetchPapers: () => axios.get(`${API_BASE_URL}/papers/`),
  createPaper: (paperData) => axios.post(`${API_BASE_URL}/papers/`, paperData),

  // Reviewer endpoints
  fetchReviewers: () => axios.get(`${API_BASE_URL}/reviewers/`),
  createReviewer: (reviewerData) => axios.post(`${API_BASE_URL}/reviewers/`, reviewerData),

  // Settings endpoints
  fetchSettings: () => axios.get(`${API_BASE_URL}/settings/`),
  createSetting: (settingsData) => axios.post(`${API_BASE_URL}/settings/`, settingsData),
};

export default apiService;
