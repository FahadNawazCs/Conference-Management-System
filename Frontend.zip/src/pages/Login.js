import React, { useState } from "react";
import "./Login.css";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import axios from 'axios';
import { useNavigate } from "react-router-dom";
import SignUp from "./SignUp";

const Login = () => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const navigate = useNavigate();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setCredentials(prevCredentials => ({
      ...prevCredentials,
      [name]: value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('/api/login/', credentials);
      console.log('Login successful', response.data);

      // Store the token and user role
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('role', response.data.role);

      navigate('/home');
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  const toggleView = () => {
    setIsLoginView(!isLoginView);
  };

  return isLoginView ? (
    <div className="main-container">
      <div className="login-container">
        <h1>User Login</h1>
        <form className="form-body" onSubmit={handleSubmit}>
          <div className="textbox">
            <TextField
              id="username"
              label="Username"
              variant="filled"
              style={{ width: "18rem" }}
              name="username"
              value={credentials.username}
              onChange={handleChange}
            />
          </div>
          <div className="textbox">
            <TextField
              id="password"
              label="Password"
              variant="filled"
              type="password"
              style={{ width: "18rem" }}
              name="password"
              value={credentials.password}
              onChange={handleChange}
            />
          </div>
          <div className="login-button">
            <Button
              variant="contained"
              style={{ width: "18rem", height: "3rem" }}
              type="submit"
            >
              LOGIN
            </Button>
          </div>
          <Button onClick={toggleView}>
            Don't have an account? Sign up
          </Button>
        </form>
      </div>
    </div>
  ) : (
    <SignUp onToggle={toggleView} />
  );
};

export default Login;
