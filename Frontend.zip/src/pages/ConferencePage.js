import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import { Link } from 'react-router-dom';
import './ConferencePage.css';

const ConferencePage = () => {
    const [papers, setPapers] = useState([]);
    const [conferenceName, setConferenceName] = useState('');
    const [role, setRole] = useState('');

    useEffect(() => {
        // Retrieve the user role from localStorage
        const userRole = localStorage.getItem('role');
        if (userRole) {
            setRole(userRole);
        }

        const storedConferenceName = localStorage.getItem('currentConferenceName');
        if (storedConferenceName) {
            setConferenceName(storedConferenceName);

            const fetchPapers = async () => {
                try {
                    const url = `/api/papers/?conference_name=${encodeURIComponent(storedConferenceName)}`;
                    const response = await axios.get(url);
                    if (response.data) {
                        setPapers(response.data);
                    } else {
                        setPapers([]);
                    }
                } catch (error) {
                    console.error('Failed to fetch papers:', error);
                    setPapers([]);
                }
            };

            fetchPapers();
        } else {
            setConferenceName("Not specified");
            setPapers([]);
        }
    }, []);

    const handlePaperSubmissionClick = () => {
        localStorage.setItem('currentConferenceName', conferenceName);
    };

    return (
        <div>
            <Navbar />
            <h1>Papers for Conference {conferenceName}</h1>
            {role === 'author' && (
                <button className='papersubmissionbutton' onClick={handlePaperSubmissionClick}>
                    <Link to="/paper-submission" style={{ color: "blue", textDecoration: "none" }}>
                        Submit Paper
                    </Link>
                </button>
            )}
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Files</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {papers.length > 0 ? papers.map(paper => (
                        <tr key={paper.id}>
                            <td>{paper.title}</td>
                            <td>
                                {paper.uploaded_file ? (
                                    <a href={paper.uploaded_file} target="_blank" rel="noopener noreferrer">View</a>
                                ) : 'No files available'}
                            </td>
                            <td>
                                <button>Edit</button>
                                <button>Delete</button>
                            </td>
                        </tr>
                    )) : <tr><td colSpan="3">No papers found.</td></tr>}
                </tbody>
            </table>
        </div>
    );
};

export default ConferencePage;
