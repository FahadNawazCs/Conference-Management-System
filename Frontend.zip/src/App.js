import "./App.css";
import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import Profile from "./pages/Profile";
import EditEmail from "./pages/EditEmail";
import CreateConference from "./pages/CreateConference";
import ConferencePage from "./pages/ConferencePage";
import PaperSubmission from './pages/PaperSubmission';
import ExtractKeywords from './pages/ExtractKeywords';
import PotentialReviewers from "./pages/PotentialReviewers";



function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/sign-up" element={<SignUp />} />
        <Route path="/home" element={<Home />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/edit-email" element={<EditEmail />} />
        <Route path="/create-conference" element={<CreateConference />} />
        <Route path="/conference-page" element={<ConferencePage />} />
        <Route path="/paper-submission" element={<PaperSubmission />} />
        <Route path="/extract-keywords" element={<ExtractKeywords />} />
        <Route path="/potential-reviewers" element={<PotentialReviewers />} />

      </Routes>
    </div>
  );
}

export default App;
