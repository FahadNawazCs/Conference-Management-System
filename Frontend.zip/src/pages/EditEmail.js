import React, { useState } from 'react';
import axios from 'axios';  // Import axios for making HTTP requests
import "./EditEmail.css";
import Navbar from "../components/Navbar"; // Adjust the path as per your project structure
import { Link } from 'react-router-dom';  // Import useNavigate

const ChangeEmailForm = () => {
  const [emailFields, setEmailFields] = useState({
    currentEmail: '',
    newEmail: '',
    confirmEmail: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEmailFields({
      ...emailFields,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (emailFields.newEmail === emailFields.confirmEmail) {
      // Prepare data for the API
      const emailData = {
        currentEmail: emailFields.currentEmail,
        newEmail: emailFields.newEmail,
      };

      try {
        // Replace '/api/update-email/' with your actual endpoint
        const response = await axios.post('/api/update-email/', emailData, {
          headers: { Authorization: `Token ${localStorage.getItem('token')}` },
        });

        // Handle success
        console.log('Email updated successfully', response.data);
        // You might want to update the UI or give feedback to the user here
      } catch (error) {
        // Handle errors, e.g., show an error message
        console.error('Error updating email:', error.response?.data || error.message);
      }
    } else {
      console.error('The new emails do not match!');
      // Provide feedback to the user that emails do not match
    }
  };

  return (
    <div>
      <Navbar/>
    <div className="change-email-form">
      <form onSubmit={handleSubmit}>
        <h2>Change Email</h2>
        <div>
          <label>* Current Email</label>
          <input
            type="email"
            name="currentEmail"
            value={emailFields.currentEmail}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>* New Email</label>
          <input
            type="email"
            name="newEmail"
            value={emailFields.newEmail}
            onChange={handleInputChange}
            required
          />
        </div>
        <div>
          <label>* Confirm Email</label>
          <input
            type="email"
            name="confirmEmail"
            value={emailFields.confirmEmail}
            onChange={handleInputChange}
            required
          />
        </div>        <div className="form-actions">
          <button type="submit">OK</button>
          <button type="button">
          <Link to="/profile" style={{ color: "blue", textDecoration: "none" }}>
            Cancel
          </Link>          
          </button>
        </div>
      </form>
    </div>
    </div>
  );
};

export default ChangeEmailForm;
