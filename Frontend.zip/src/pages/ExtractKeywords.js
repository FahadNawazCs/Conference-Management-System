import React, { useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import './ExtractKeywords.css';

const ExtractKeywords = () => {
    const [result, setResult] = useState(null);
    const [error, setError] = useState(null);

    const handleExtractKeywords = async () => {
        setError(null);
        setResult(null);
        const formData = new FormData();
        const fileInput = document.querySelector('input[type="file"]');
        formData.append('file', fileInput.files[0]);

        try {
            const response = await axios.post('/api/extract_keywords/', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            setResult(response.data.extracted_keywords);
        } catch (error) {
            console.error('Error extracting keywords:', error);
            setError('Failed to extract keywords.');
        }
    };

    return (
        <div>
            <Navbar />
            <h1>Extract Keywords from PDF</h1>
            <div>
                <label>Upload PDF File:</label>
                <input type="file" accept="application/pdf" required />
            </div>
            <button onClick={handleExtractKeywords}>Extract Keywords</button>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            {result && (
                <div>
                    <h2>Extracted Keywords:</h2>
                    <ul>
                        {result.map((keyword, index) => (
                            <li className='list' key={index}>{keyword}</li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default ExtractKeywords;
