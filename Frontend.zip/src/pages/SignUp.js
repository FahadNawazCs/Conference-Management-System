import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import axios from 'axios';
import { useNavigate } from "react-router-dom";

const SignUp = ({ onToggle }) => {
  const [credentials, setCredentials] = useState({
    username: '',
    password: '',
    email: '',
    phone: '',
    realName: '',
    institution: '',
    googleScholarId: '',
    role: 'author'  // Default role set to 'author'
  });
  const navigate = useNavigate();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setCredentials(prevCredentials => ({
      ...prevCredentials,
      [name]: value,
    }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('/api/signup/', credentials);
      console.log('Sign up successful', response.data);

      // Store the user role
      localStorage.setItem('role', credentials.role);

      onToggle(); // Switch to login view upon successful signup
    } catch (error) {
      console.error('Error signing up:', error);
    }
  };

  return (
    <div className="main-container">
      <div className="login-container">
        <h1>User Sign Up</h1>
        <form className="form-body" onSubmit={handleSubmit}>
          <div className="textbox">
            <TextField
              id="username"
              label="Username"
              variant="filled"
              style={{ width: "18rem" }}
              name="username"
              value={credentials.username}
              onChange={handleChange}
            />
          </div>
          <div className="textbox">
            <TextField
              id="email"
              label="Email"
              variant="filled"
              type="email"
              style={{ width: "18rem" }}
              name="email"
              value={credentials.email}
              onChange={handleChange}
            />
          </div>
          <div className="textbox">
            <TextField
              id="password"
              label="Password"
              variant="filled"
              type="password"
              style={{ width: "18rem" }}
              name="password"
              value={credentials.password}
              onChange={handleChange}
            />
          </div>
          <div className="textbox">
            <TextField
              id="realName"
              label="Full Name"
              variant="filled"
              style={{ width: "18rem" }}
              name="realName"
              value={credentials.realName}
              onChange={handleChange}
            />
          </div>
          <div className="textbox">
            <TextField
              id="phone"
              label="Phone Number (Optional)"
              variant="filled"
              style={{ width: "18rem" }}
              name="phone"
              value={credentials.phone}
              onChange={handleChange}
            />
          </div>
          <div className="textbox">
            <TextField
              id="institution"
              label="Institution (Optional)"
              variant="filled"
              style={{ width: "18rem" }}
              name="institution"
              value={credentials.institution}
              onChange={handleChange}
            />
          </div>
          <div className="textbox">
            <TextField
              id="googleScholarId"
              label="Google Scholar ID"
              variant="filled"
              style={{ width: "18rem" }}
              name="googleScholarId"
              value={credentials.googleScholarId}
              onChange={handleChange}
            />
          </div>
          <div className="textbox">
            <FormControl variant="filled" style={{ width: "18rem" }}>
              <InputLabel id="role-label">Role</InputLabel>
              <Select
                labelId="role-label"
                id="role"
                name="role"
                value={credentials.role}
                onChange={handleChange}
                required
              >
                <MenuItem value="author">Author</MenuItem>
                <MenuItem value="chair">Chair</MenuItem>
                <MenuItem value="reviewer">Reviewer</MenuItem>
              </Select>
            </FormControl>
          </div>
          <div className="login-button">
            <Button
              variant="contained"
              style={{ width: "18rem", height: "3rem" }}
              type="submit"
            >
              SIGN UP
            </Button>
            <Button
              variant="text"
              onClick={onToggle}
              style={{ marginTop: "1rem" }}
            >
              Already have an account? Log in
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SignUp;
