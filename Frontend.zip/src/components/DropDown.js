import * as React from "react";
import { useState, useEffect } from "react";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';

const selectStyle = {
  color: "white",
  "&:before": {
    borderColor: "white",
  },
  "&:after": {
    borderColor: "white",
  },
  "&:hover:not(.Mui-disabled):before": {
    borderColor: "white",
  },
};

const menuStyle = {
  color: "white",
  backgroundColor: "#333",
  display: "flex",
  flexDirection: "column",
};

export default function DropDown() {
  const [selectedValue, setSelectedValue] = useState("");
  const [userName, setUserName] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('/api/profile/', { headers: { Authorization: `Token ${localStorage.getItem('token')}` } })
      .then(response => {
        setUserName(response.data.real_name); // Adjust depending on how the username is returned
      })
      .catch(error => {
        console.error('Error fetching user profile:', error);
      });
  }, []);

  const handleChange = (event) => {
    const value = event.target.value;
    setSelectedValue(value);

    if (value === "logout") {
      localStorage.removeItem('token');
      navigate('/');
    }
  };

  return (
    <FormControl sx={{ m: 1, minWidth: 140 }} size="small">
      <InputLabel id="demo-select-small-label" style={{ color: "white" }}>{userName || "Loading..."}</InputLabel>
      <Select
        labelId="demo-select-small-label"
        id="demo-select-small"
        style={selectStyle}
        MenuProps={{ PaperProps: { style: menuStyle } }}
        value={selectedValue}
        onChange={handleChange}
      >
        <MenuItem value="home">
          <Link to="/home" style={{ color: "white", textDecoration: "none" }}>
            Home
          </Link>
        </MenuItem>
        <MenuItem value="profile">
          <Link to="/profile" style={{ color: "white", textDecoration: "none" }}>
            Profile
          </Link>
        </MenuItem>
        <MenuItem>
          <Link to='/potential-reviewers' style={{ color: "white", textDecoration: "none" }}>
            Potential Reviewers
          </Link>
        </MenuItem>
        <MenuItem value="logout">
          Logout
        </MenuItem>
      </Select>
    </FormControl>
  );
}
